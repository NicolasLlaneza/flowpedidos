# Correcciones pendientes tras la devolución del 18/09

Verificación del artefacto contra los 31 hallazgos nuevos de la tercera auditoría,
con el cambio exacto a aplicar en cada caso.

> **Revisión del 29/09.** Se sumó trabajo sobre `scripts/dashboard/` (§6) y un
> hallazgo nuevo sobre la evidencia del indicador de anclaje (§7.C), que conviene
> leer junto al punto 5 del orden sugerido porque son la misma corrección.

> **No descomprimas un ZIP sobre el repositorio.** Esta verificación se hizo sobre
> una copia sin `.git`, que no tiene los cambios posteriores a su descarga. Por eso
> **no se modificó ningún archivo compartido**: lo único que cambió es
> `scripts/dashboard/`. Todo lo demás está acá escrito para aplicarse a mano sobre
> el repositorio al día.

---

## 1. Lo que ya está corregido

Verificado en el artefacto, no hace falta volver a tocarlo.

| Hallazgo | Verificación |
|---|---|
| **NA-04** | `evidencia/2000018256113704.json` existe y ya no está en `mocks/data/orders/`. |
| **NA-08** | `sql/modelo-er.png` regenerado (4062 × 3203 px; el tribunal vio 1410 × 1055) y el `.dot` incluye `raw_events`, `ack_at`, `dispatched_at`, `atributos_usados`, `validator_passes` y `wa_message_id`. |
| **NC-04** | `context.md` y `out/baseline-pipeline-times.csv` eliminados. Queda un residual, abajo. |

---

## 2. Bloque 0 — antes que cualquier otra cosa

### NC-04 · residual

`scripts/generate-baseline-wc-orders.mjs`, **línea 21**: un comentario de ejemplo de
uso conserva los cuatro números de teléfono completos de los destinatarios reales.

```js
//   node scripts/generate-baseline-wc-orders.mjs --phones "+549261XXXXXXX,+549261XXXXXXX,..."
```

Reemplazar por un ejemplo sin datos reales:

```js
//   node scripts/generate-baseline-wc-orders.mjs --phones "+5492610000001,+5492610000002"
```

Falta además confirmar que el historial de git quedó purgado: los commits anteriores
conservan el contenido aunque el archivo actual esté limpio.

---

## 3. Bloque 1 — correspondencia documento ↔ artefacto

### NC-01 · el nodo de enriquecimiento

Conviene separar dos afirmaciones que el hallazgo mezcla.

**Lo que está probado.** La integración contra la API de Órdenes funciona. Se validó
el flujo de autorización y la consulta del recurso contra una cuenta de prueba real,
y la respuesta se publica en `evidencia/2000018256113704.json`. Se verificó su
contenido: trae `id`, `date_closed`, `pack_id`, `mediations` y `payments`, es decir
la estructura que la plataforma devuelve. Eso no está en discusión y el §3.11 lo
declara bien.

**Lo que las tablas afirman de más.** Los tres workflows del repositorio —
`workflow.json`, `workflow_v1.3_import.json` y `workflow_v1.3_import.local.json` —
configuran el nodo con `http://mock-marketplace/orders/{order_id}`, y la cadena
`api.mercadolibre` no aparece en ninguno. Las Tablas 4.1 y C.1 dicen que el nodo
«opera hoy sobre la API real de Mercado Libre» y «opera sobre datos reales», lo cual
contradice **al propio documento**: el §1.7, el §3.11, la Tabla 5.6 y el Abstract
declaran los cuatro que el canal operó contra un servicio local de simulación en la
corrida reportada. Son las dos tablas las que quedaron fuera de línea con el resto
de la tesis.

**Por qué no conviene resolverlo apuntando el nodo a la API real.** El §3.11 explica
la restricción: el entorno de prueba no permite avanzar el estado de una orden, de
modo que la compra queda fijada en pagado. Se comprueba en la evidencia publicada:
`status: paid` y sin campo `shipping.status`. Si el canal pasara a consultar la API
real, solo podría producir pedidos pagados, y con eso se perdería lo que la Tabla 5.6
declara como su contribución probatoria — «ejercita los siete estados canónicos del
modelo, incluidas las que el entorno de prueba de la plataforma no permite
alcanzar» —. Habría además que rehacer la corrida, que la devolución dice
expresamente que no hace falta, y el segundo factor de autenticación sigue bloqueado.

La asimetría actual está bien pensada: WooCommerce aporta plataforma real, Mercado
Libre aporta cobertura de estados. Deshacerla debilitaría el trabajo.

#### Cambio propuesto: volver cierta la afirmación sin tocar la corrida

En lugar de degradar las tablas a «opera sobre el simulador», conviene que el nodo
consulte **la API de Órdenes**, con el destino configurable, y que el documento
declare contra qué apuntó en la corrida reportada.

**1. URL configurable.** En el nodo, reemplazar el campo URL por:

```
={{ $env.ML_API_BASE || 'http://mock-marketplace' }}/orders/{{ $("Validate webhook").item.json.order_id }}
```

**2. Encabezado de autorización.** El nodo hoy no envía ninguno
(`sendHeaders` ausente, `authentication` ninguna). Activar *Send Headers* y agregar:

| Nombre | Valor |
|---|---|
| `Authorization` | `=Bearer {{ $env.ML_ACCESS_TOKEN }}` |

Se puede enviar siempre: el simulador nginx lo ignora, así que no hace falta
condicionarlo. La variable ya existe en el `.env` y la genera `scripts/ml-setup.mjs`.

**3. Variable de entorno.** Agregar al bloque `environment` del servicio `n8n` en
`docker-compose.yml`, junto a las otras:

```yaml
      # Destino del enriquecimiento del canal ML. Por defecto el simulador local;
      # apuntar a https://api.mercadolibre.com cuando las credenciales de la
      # cuenta de prueba lo permitan (§3.11).
      ML_API_BASE: ${ML_API_BASE:-http://mock-marketplace}
      ML_ACCESS_TOKEN: ${ML_ACCESS_TOKEN}
```

`N8N_BLOCK_ENV_ACCESS_IN_NODE` ya está en `"false"`, así que `$env` funciona en las
expresiones sin cambios adicionales.

**4. Renombrar el nodo.** `Enrich from mock` → `Enrich order`. Se verificó que es
seguro: ninguna expresión lo referencia por nombre, solo figura en `connections`
—como origen y como destino de `ACK 200 ML`—, y n8n reescribe las conexiones al
renombrar desde la interfaz. Hay que actualizar la Tabla C.1, que lo lista.

#### Redacción sugerida para las tablas

> Consulta el recurso de orden en la API de Órdenes de la plataforma. El destino es
> configurable mediante `ML_API_BASE`; en la corrida reportada apuntó al servicio
> local de simulación, por las restricciones del entorno de prueba que declara la
> sección 3.11.

Así la arquitectura queda descrita por lo que hace —consultar la API de Órdenes— sin
afirmar sobre la corrida algo que el resto del documento desmiente. Y aporta de paso
una propiedad que la devolución valora: que el diseño no dependa de la plataforma.

> Este cambio **no obliga a rehacer la corrida**. El comportamiento por defecto es
> idéntico al actual: sin `ML_API_BASE` definida, el nodo consulta el mismo
> simulador y produce los mismos resultados.

### NA-02 · tres descripciones incompatibles de la falla del proveedor

Verificado en `workflow.json`: el nodo `Call OpenAI` (índice 15, id `v13-call-openai`)
tiene exactamente estas claves — `parameters, type, typeVersion, position, id, name` —
es decir **ninguna configuración de error**, y su única conexión saliente va a
`Parse LLM Response`. Un fallo detiene la ejecución. El §5.5 lo describe bien; el
§4.3.2 y el §7.4 no.

Hay dos caminos y conviene elegir uno explícitamente:

**a) Solo documento (mínimo).** Corregir §4.3.2 y §7.4 para que digan lo que el §5.5
ya dice: ante el cierre de conexión del proveedor el pedido queda persistido sin
notificación. El §7.4 además confunde este caso con el de WC-16, que es otro.

**b) Documento y artefacto.** Además de lo anterior, configurar el nodo. En la
interfaz de n8n: *Settings → On Error → Continue (using error output)*, y arrastrar
la salida de error hasta `Fallback template`. Para el fallo transitorio, activar
*Retry On Fail* con 3 intentos y 1000 ms de espera, que es la séptima recomendación
del §8.1.

Si se toma (b), el artefacto deja de coincidir con la corrida reportada, así que hay
que declararlo como corrección posterior a la corrida del Capítulo 5 y no rehacerla.

### NA-03 · los pedidos de WooCommerce no salen de un checkout

Verificado: ni `wc-simulate-checkout.mjs` ni `generate-baseline-wc-orders.mjs`
recorren el proceso de compra; crean los pedidos por la API REST.

Corregir Resumen, Abstract, §1.7, §3.4, §3.11 y §5.1. Redacción sugerida:

> pedidos creados mediante la API REST de una instalación de prueba real de la
> plataforma, que emite su webhook nativo

Revisar además el argumento de factibilidad del §3.4, que apoya el tamaño muestral
en el costo de recorrer el checkout.

### NM-01 · la migración v1.2.0 agrega un campo, no tres

Verificado: `sql/03_wa_dispatch.sql` tiene un solo `ADD COLUMN`, en la línea 19, y es
`wa_message_id`. La prosa del **Anexo B.2** anuncia `wa_message_id`, `message_status`
y `error_message`. Los otros dos ya venían del esquema inicial.

### NM-02 · comentarios del DDL contradicen el prompt vigente

| Archivo | Línea | Dice hoy | Problema |
|---|---|---|---|
| `sql/01_schema.sql` | 27 | `el pipeline envía 'pseudonym' al modelo, nunca el nombre/email real` | El prompt v2 **no** envía el seudónimo |
| `sql/01_schema.sql` | 50 | `pseudonym se usa al invocar el LLM` | ídem |
| `sql/01_schema.sql` | 51 | `Token opaco enviado al LLM en lugar de PII` | ídem |
| `sql/02_roles.sql` | 15 | `Esto se alinea con el cap 5.7 del documento` | No existe un cap 5.7 |

Los tres primeros describen el prompt v1, deprecado. El contexto que hoy recibe el
modelo no incluye ningún identificador del comprador, ni siquiera el seudónimo, y el
propio nodo aborta la llamada si detecta uno. Redacción sugerida para la línea 51:

```sql
COMMENT ON COLUMN tfi.customers.pseudonym IS
  'Token opaco de uso interno; NO se envía al modelo — el contexto excluye todo identificador del comprador (§4.3.1)';
```

### Extra · el healthcheck del mock informa mal

No está en la devolución, pero se detectó al levantar el stack. `docker compose ps`
muestra `tfi-mock-marketplace` como `unhealthy` aunque el servicio responda
correctamente: el healthcheck consulta `http://localhost/healthz`, y dentro del
container `localhost` resuelve primero a `::1`, mientras que `mocks/nginx.conf`
declara `listen 80;` — solo IPv4. Desde afuera funciona porque el mapeo del puerto
entra por IPv4.

En `docker-compose.yml`, servicio `mock-marketplace`, línea 110:

```yaml
    healthcheck:
      # 127.0.0.1 y no localhost: dentro del container localhost resuelve primero
      # a ::1, y nginx.conf declara `listen 80;` — solo IPv4.
      test: ["CMD-SHELL", "wget --quiet --tries=1 --spider http://127.0.0.1/healthz || exit 1"]
```

Verificado: tras el cambio el container pasa a `healthy` en unos 30 segundos.

### NA-09 y NA-07

- **NA-09**: sustituir NIST SP 800-162 (trata ABAC) por NIST SP 800-53 control AC-6,
  o por Ferraiolo et al. (2001) que el trabajo ya cita, y agregar la entrada en el
  Capítulo 9.
- **NA-07**: completar la declaración de originalidad con el uso de herramientas de
  IA. El tribunal encontró commits con `Co-Authored-By` de un asistente y una rama
  `claude/…` en el PR n.º 1, y **no lo imputó como falta**, pero pidió que la
  declaración lo consigne. Conviene resolverlo antes de sumar más trabajo asistido:
  el tablero incluye código escrito con asistencia de IA, y eso también corresponde
  declararlo.

---

## 4. Bloque 2 — reanálisis

### NA-01 · el rechazo del validador es un falso positivo, y el arreglo evidente no alcanza

Confirmado por partida doble. El pedido rechazado en la corrida tiene
`external_id = 70`, y `out/corrida-v2.csv` lo registra como la única fila con
`is_fallback = true`. Además se **reprodujo de forma independiente** el 28/09 sobre
otro pedido: `customer_id = 99`, mensaje rechazado por `contiene '99'`, donde el `99`
estaba dentro de `5299.46`, el precio del pedido. Dos identificadores distintos, dos
contextos distintos, el mismo defecto.

Deja de ser una anécdota y pasa a ser un patrón demostrado, lo cual conviene para el
§5.4 y el §6.1.

**Sobre el arreglo.** La devolución sugiere «delimitadores de palabra o prefijo».
Se probó, y `\b` por sí solo **no corrige el caso que originó el hallazgo**: en
`175/70` el carácter `/` cuenta como límite de palabra, de modo que `\b70\b` sigue
marcando. Resultado de contrastar tres implementaciones sobre siete casos —los dos
falsos positivos reales más cinco construidos:

| Implementación | Errores sobre 7 casos |
|---|---|
| `msg.includes(id)` (actual) | 4 |
| `\b` + id + `\b` | 1 |
| Propuesta | 0 |

En `n8n-workflows/lib/rehydrate-validate.js`, **línea 64**, reemplazar:

```js
for (const id of idsPresentes) {
    if (msg.includes(id)) {
        failures.push({ regla: 'sin_identificadores_internos', detalle: `contiene '${id}'` });
    }
}
```

por:

```js
const escapar = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
for (const id of idsPresentes) {
    // El identificador no debe estar pegado a un dígito, a una letra ni a un
    // separador numérico. Con \b solo no alcanza: en "175/70" la barra cuenta
    // como límite de palabra y el identificador "70" seguiría marcándose, que
    // es exactamente el falso positivo de la corrida reportada.
    const rx = new RegExp('(?<![\\p{L}\\p{N}/.,-])' + escapar(id) + '(?![\\p{L}\\p{N}/])', 'u');
    if (rx.test(msg)) {
        failures.push({ regla: 'sin_identificadores_internos', detalle: `contiene '${id}'` });
    }
}
```

El mismo cambio hay que aplicarlo dentro del nodo `Rehydrate + validate` de
`workflow.json`, que lleva su propia copia del código.

Falta además publicar el `validator_failures` de WC-16 y el texto rechazado, que la
devolución pide expresamente.

### NC-05 · la causa declarada del defecto de ítems no se sostiene

El §5.5 atribuye la interrupción a «un ítem cuya cantidad no admite conversión
numérica». Los tres pedidos afectados tienen cantidades `4`, `1` y `2`, **todas
numéricas**, y el normalizador aplica `Number(oi.quantity) || 1`, que con esos
valores no puede fallar. Los tres tienen además `status: invalid_unknown_X`.

Hay que recuperar el error real de la ejecución de n8n. Con el stack levantado:

```bash
docker compose exec -T postgres psql -U n8n -d tfi -c \
  "SELECT id, status, \"startedAt\" FROM public.execution_entity ORDER BY id DESC LIMIT 20;"

docker compose exec -T postgres psql -U n8n -d tfi -tAc \
  "SELECT data FROM public.execution_data WHERE \"executionId\" = <id>;" > exec.json
```

En `exec.json` el mensaje figura junto a `lastNodeExecuted`. Conviene publicarlo y
corregir el §5.5 con la causa verdadera.

Sobre el denominador de H2, el tablero ya publica las tres tasas con su intervalo de
Wilson y su denominador escrito, y reproduce el cálculo de la devolución:

| Tasa | | IC 95 % | Juicio |
|---|---|---|---|
| Admisión estructural | 148/150 = 98,7 % | [95,3; 99,6] | valida |
| Condicional · solo cabecera | 148/148 = 100 % | [97,5; 100] | valida |
| Condicional · exige ítems | 145/148 = 98,0 % | [94,2; 99,3] | **solo compatible** |

Falta declarar en §3.3 cuál se adopta y reportar ambas en §5.3, y retirar el estado
`error` de los «siete estados cubiertos» de la Tabla 5.6 o calificarlo como
«ejercitado con falla».

### NA-06 y NC-03 son el mismo problema

`out/corrida-v2.csv` tiene 19 columnas y **ninguna es `message_text`**. De ahí se
siguen dos cosas:

- No se puede acreditar que los 75 despachos reales salieran con saludo único (NA-06).
- No se puede calcular el indicador de anclaje del §3.3 desde la evidencia publicada
  (NC-03), porque requiere el texto de cada mensaje.

**Agregar `message_text` al CSV de la corrida cierra los dos de una vez**, y el
tablero calcula el anclaje automáticamente. Si se publica el texto, conviene ofuscar
el nombre del destinatario como ya hace el Anexo E.

Mientras tanto el tablero lo calcula con `--from-db` sobre la base de la corrida:
verificación de **presencia textual** de cada atributo en el mensaje, que es lo que el
§3.3 define y lo que la regla 2 del validador no hace.

---

## 5. Bloque 3 — el panel

`scripts/panel/ronda-3/` ya está armado y responde a NC-02: 18 mensajes, **cero
saludos**, ítem de conjetura de origen, reglas de decisión propias y un protocolo de
preregistro correcto (la clave se commitea recién al cerrar). **Falta ejecutarlo**: no
hay `corpus_key_r3.csv` ni respuestas.

Es la opción «preferible» de la devolución y la que más mueve la calificación, porque
H3 pesa sobre el Capítulo 5.

---

## 6. Qué cambió en `scripts/dashboard/`

El tablero es la Figura 8.1. Se encontró que **mostraba los datos de otra corrida**:

| | Figura 8.1 (antes) | Capítulo 5 |
|---|---|---|
| Pedidos persistidos | 147 | 148 |
| Mensajes generados | 141 | 143 |
| Degradaciones | **0** | **1** |
| Aprobados 1er intento | 141 | 142 |
| Costo total | USD 0,020653 | USD 0,020929 |

La distribución por estado tampoco coincidía con la Tabla C.2. Cambios aplicados:

1. **El exportador lee `out/corrida-v2.csv` por defecto.** Las siete cifras del
   Capítulo 5 se reconstruyen exactas, y el tablero se regenera **sin base de datos**:
   cualquiera que clone el repositorio obtiene las cifras del documento. Sigue
   existiendo `--from-db` para monitorear una corrida en curso.
2. **El exportador reescribe los datos embebidos de `index.html`.** La
   desincronización que produjo la figura equivocada deja de ser posible.
3. **La confirmación al emisor deja de mostrar «0 ms».** El tablero presentaba ese
   cero como una medición, con tilde verde, sobre 147 pedidos — y el §5.2 dice que
   «reportarlo como latencia sería un error». Ahora muestra la medición externa
   (mediana 38 ms, máximo 131, n = 30) con el umbral dibujado y la salvedad de cota
   inferior.
4. **Las tres tasas de normalización** con su intervalo de Wilson y su denominador.
5. **Detalle del validador**, con la advertencia automática cuando el identificador
   del pedido rechazado tiene pocos dígitos.
6. **Indicador de anclaje contextual**, ver abajo.
7. **El histograma se separa por modo de despacho**, porque los dos no son comparables.
8. **Detalle por pedido**: cada agregado se abre y muestra los pedidos que lo
   producen. Los 148 viajan embebidos, así que funciona con `file://`.

### El indicador de anclaje ya no aparece como un hueco

La tarjeta decía **«No computable desde esta fuente»**, porque `corrida-v2.csv` no
lleva `message_text`. Eso anunciaba una carencia en una figura del documento, y era
peor que el problema real: **el resultado sí está publicado** en
`out/anclaje-resultado.txt`.

Ahora el exportador lee ese archivo y la tarjeta muestra **97,9 % [94,0; 99,3]**
(139 de 142), con el desglose por atributo *verificado en el texto* contra
*declarado por el modelo* — que deja ver dónde se ancla el modelo (`primary_product_name`
en 139, `items_count` en 14, `total_amount` y `source_created_at` en ninguno) y la
brecha de 3 mensajes que declaran un atributo y no lo citan, que es justamente la
debilidad de la regla 2 del validador. Se informa aparte que el modelo declara
`order_status` en los 142, que no es anclaje verificable.

Tres decisiones que conviene conocer por si las preguntan en la defensa:

- **El valor se lee del archivo, no está escrito a mano en el código.** Mismo motivo
  por el que el exportador reescribe el bloque embebido: un número copiado se separa
  de su fuente, y esta figura ya sufrió esa divergencia una vez.
- **El exportador recalcula el intervalo de Wilson y lo contrasta con el que imprime
  el archivo**; si difieren más de 0,15 puntos, avisa. Hoy coinciden exactamente, lo
  que confirma que el analizador en Python y el tablero hablan de la misma corrida.
- **La tarjeta declara que el valor es citado y no recalculado**, y dice qué haría
  falta para que fuera reproducible como el resto. Ver §7.C.

### El tablero avisa si la corrida cambia

Importa para cuando se ejecute una corrida nueva. **Correr una corrida no afecta al
tablero**: el exportador lee específicamente `out/corrida-v2.csv`, y `run-corrida.mjs`
escribe en el archivo que se le pase por `--out`. El tablero sólo cambia si se
reemplaza ese archivo a propósito, o si se usa `--from-db`.

Para ese caso se agregaron tres controles. **Ninguno se activa con la corrida
reportada** —se verificó que el `dashboard-data.json` sale idéntico— y existen para
que una corrida nueva no produzca una figura equivocada en silencio:

1. **El indicador de anclaje no se publica si no corresponde a la corrida.**
   `out/anclaje-resultado.txt` y `out/corrida-v2.csv` son dos archivos distintos:
   regenerar el segundo sin volver a correr `analizar-anclaje.py` daría indicadores
   nuevos con un anclaje viejo. El exportador contrasta los mensajes que evaluó el
   analizador contra los que generó el modelo, y ante cualquier discrepancia la
   tarjeta dice que está desactualizada y cómo regenerarla, en lugar de mostrar un
   número que no corresponde.
2. **Ningún estado canónico desaparece del gráfico.** Los siete estados del §3.2
   estaban fijos en el código y cualquier otro se descartaba sin avisar: se comprobó
   que con un estado extra las barras sumaban 148 mientras el indicador decía 150.
   Ahora se grafica al final, marcado, y se explica debajo de la tabla.
3. **Si falta el CSV, el mensaje se entiende** en vez de una traza de Node.

### Dos correcciones de presentación

- **El color contradecía al documento.** La tarjeta de los 148 pedidos persistidos se
  pintaba de ámbar porque *otra* métrica (los 5 sin notificación) era distinta de
  cero, y la de los 143 mensajes porque hubo 1 degradación — mientras la tarjeta del
  validador, que describe **ese mismo hecho**, estaba en verde. La figura marcaba como
  advertencia sus dos resultados principales, y presentaba la degradación elegante del
  §4.3.1 como una falla. Ahora el ámbar significa una sola cosa —acá hay algo que
  mirar— y lo cumple sólo «Sin notificación: 5».
- **Los decimales van con coma, como el documento.** Eran 13 lugares que interpolaban
  el número crudo: la figura decía `99.3 %` y `USD 0.0209` mientras el Capítulo 5
  escribe `99,3 %` y `USD 0,020929`. Además el costo se truncaba; ahora se muestra con
  la precisión que publica la Tabla 5.2, para que cruzar figura y tabla no exija
  explicar por qué los dígitos no coinciden.

### Lo que hay que escribir en el documento

El §8.1 describe el tablero como cobertura de «la dimensión de observación». Ahora
hace más que eso, y **si no se declara se abre otra brecha documento ↔ artefacto**.
Bastan dos o tres oraciones que digan que se regenera desde la evidencia publicada,
que informa las tasas con su intervalo y su denominador, y que permite bajar de cada
agregado a los pedidos que lo producen.

Conviene además **recortar la Figura 8.1 de nuevo** con el tablero regenerado.

---

## 7. Hallazgos que la devolución no marcó

### A. Falta el corpus que vio el panel de la ronda 2

`build-corpus-v2.mjs` genera dos archivos: `corpus_key_v2.csv` y
`corpus_blind_v2.csv`. **El segundo no está en el repositorio.** Está la clave —
origen y estado de cada mensaje— pero no los mensajes que los evaluadores puntuaron.
`corpus_key_v2.csv` tiene además `notif_id` vacío en las 14 filas, de modo que
tampoco hay trazabilidad hacia la corrida por ahí.

Un tercero no puede verificar el corpus de H3, que es el componente más cuestionado.

### B. El repositorio no se levanta siguiendo su propio README

El README afirma:

> `sql/01_schema.sql` y `sql/02_roles.sql` los carga Postgres solo, por el bind mount

Es falso. `02_roles.sql` abre con un `RAISE EXCEPTION` si no encuentra la variable
`tfi.app_password`, que no puede existir durante la inicialización automática. Se
comprobó levantando el stack desde cero el 27/09: la inicialización **se aborta ahí**,
`03` y `04` nunca corren y el rol `tfi_app` no se crea. El container se recupera y
arranca igual, de modo que parece que funcionó.

Un evaluador que clone el repositorio y siga el README obtiene una base incompleta y
un pipeline que no conecta, en el primer paso. La devolución destaca la
«Reproducibilidad real» como primera fortaleza.

Secuencia que sí funciona:

```bash
docker compose up -d postgres mock-marketplace n8n
set -a && . ./.env && set +a
{ echo "SET tfi.app_password = '${TFI_APP_PASSWORD}';"; cat sql/02_roles.sql; } \
  | docker compose exec -T postgres psql -U n8n -d tfi -v ON_ERROR_STOP=1
docker compose exec -T postgres psql -U n8n -d tfi < sql/03_wa_dispatch.sql
docker compose exec -T postgres psql -U n8n -d tfi < sql/04_instrumentation.sql
```

Verificación: `SELECT version FROM tfi.schema_version;` tiene que devolver las cuatro
versiones, de v1.0.0 a v1.3.0.

**Addendum del 29/09.** Para volver a levantar un stack ya creado, `docker compose
start` **a secas no sirve**: aborta con `wordpress is missing dependency mysql` —el
compose define cinco servicios pero sólo existen tres contenedores— y deja **n8n sin
arrancar**, aunque Postgres y el mock sí levanten. Hay que nombrarlos:

```bash
docker compose start postgres n8n mock-marketplace
```

### C. La evidencia del anclaje no se publica por un motivo que no se sostiene

`out/README.md` declara por qué no se versiona la entrada del analizador:

> La entrada del script (`out/anclaje-crudo.csv`) contiene el texto completo de los
> mensajes, **con los nombres de los destinatarios**, y por eso no se versiona.

Esa afirmación no resiste la comprobación, en dos frentes independientes:

1. **`sql/export-anclaje.sql` no selecciona ninguna columna de `tfi.customers`.** La
   consulta une `ai_notifications` con `orders`, `order_items` y un conteo; sus 16
   columnas son identificadores del pedido, atributos del producto, métricas del
   validador y `message_text`. No hay nombre, ni teléfono, ni dirección.
2. **Los mensajes no citan al destinatario.** Se contrastó cada `message_text` contra
   el nombre de pila de su cliente: **0 de 24** lo mencionan. Dicen «Tu pedido del
   Neumático Bridgestone Ecopia EP150 185/65 R14 ha sido recibido», sin nombre. Que es
   exactamente lo que la tesis afirma que hace el diseño.

**Límite de esta comprobación:** se hizo sobre 24 mensajes de una corrida local, no
sobre los 142 de la corrida reportada, que no están en esta máquina. **Hay que
confirmarlo sobre el archivo real antes de publicar nada.**

Si se confirma, el archivo se publica tal cual —sin seudonimizar— y con eso:

- El indicador de anclaje pasa de **citado** a **recalculable por un tercero**. Hoy es
  el único resultado del Capítulo 5 que no se puede reproducir desde la evidencia
  publicada; todo lo demás sale de los CSV de `out/`.
- El tablero lo computa solo: el exportador ya está preparado para las dos vías y
  etiqueta el origen (`publicado` o `computado`).
- **Se cierra de paso el hallazgo A**, porque los mismos textos son los que le faltan
  al corpus de la ronda 2.

Es la corrección con mejor relación entre esfuerzo y peso: un archivo, y toca la
reproducibilidad de dos capítulos.

---

## 8. Orden sugerido

1. **NC-04 residual** y confirmación de la purga del historial. Es condición previa a
   la defensa.
2. **NA-07**, la declaración de originalidad. Antes de sumar más trabajo asistido.
3. **Bloque 1 completo**: son ediciones de documento, no tocan el sistema.
4. **Ejecutar la ronda 3.** Es lo que más pesa y lo único que lleva tiempo de
   calendario, así que conviene lanzarlo temprano y avanzar con el resto mientras se
   recolectan las respuestas.
5. **Publicar la salida de `sql/export-anclaje.sql`** (§7.C), previa confirmación de
   que no lleva datos del destinatario. Es un solo archivo y cierra cuatro cosas a la
   vez: NA-06, NC-03, el corpus faltante de la ronda 2 (§7.A) y la reproducibilidad
   del indicador de anclaje. Después, regenerar el tablero y recortar la Figura 8.1.
6. **Recuperar el error real de la ejecución** para NC-05.
7. **Regla 1 del validador** y, si se decide, la salida de error de `Call OpenAI`.
8. Corregir el README —el de la raíz por §7.B, el de `out/` por §7.C— y publicar
   `corpus_blind_v2.csv` si el punto 5 no lo dejó cubierto.
